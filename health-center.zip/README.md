# 지도 정보 공유하기

- 사용자가 보건소 클릭
  : 시각적으로 아이콘 교체
  : 클릭된 좌표를 보관(복사) : SWR

## 클릭정보 처리하기

- 1. 커스텀 훅
     : /src/hooks/useCurrentInfo.ts

```ts
import { Info } from '@/types/info';
import { useCallback } from 'react';
import { mutate } from 'swr';
// SWR 보관용 구분키
export const CURRENT_INFO_KEY = '/health-info';

export const useCurrentInfo = () => {
  // 현재 좌표정보를 SWR 에 저장하기
  const setCurrentInfo = useCallback((info: Info) => {
    // SWR 업데이트
    mutate(CURRENT_INFO_KEY, info);
  }, []);

  // 저장된 좌표정를 SWR 에 지우기
  const clearCurrentInfo = useCallback(() => {
    // SWR 초기화
    mutate(CURRENT_INFO_KEY, null);
  }, []);

  return { setCurrentInfo, clearCurrentInfo };
};
```

- 2. onClick 에서 좌표저장
     : src/components/home/Markers.tsx

```tsx
'use client';
import { Marker } from '@/types/map';
import React, { useEffect } from 'react';

const Marker = ({ map, coordinates, icon, onClick }: Marker) => {
  // 컴포넌트 배치시 기본 출력 처리
  useEffect(() => {
    // https://navermaps.github.io/maps.js.ncp/docs/tutorial-2-Marker.html
    let marker: naver.maps.Marker | null = null;
    if (map) {
      // 마커를 출력한다.
      marker = new naver.maps.Marker({
        position: new naver.maps.LatLng(...coordinates),
        map: map,
        icon: icon,
      });
    }
    // 컴포넌트가 제거될때 실행할 cleanup 함수
    return () => {
      marker?.setMap(null);
    };

    // 지도 객체가 변화가 일어나면 처리하라
    // Dependency Array (의존성배열)
  }, [map]);

  // 네이버 마커 아이콘은 네이버가 랜더링합니다
  return null;
};

export default Marker;
```

- 3. onClick 처리(아이콘 바꾸기)
     : src/components/home/Marker.tsx

```tsx
'use client';
import { Marker } from '@/types/map';
import React, { useEffect } from 'react';

const Marker = ({ map, coordinates, icon, onClick }: Marker) => {
  // 컴포넌트 배치시 기본 출력 처리
  useEffect(() => {
    // https://navermaps.github.io/maps.js.ncp/docs/tutorial-2-Marker.html
    let marker: naver.maps.Marker | null = null;
    if (map) {
      // 마커를 출력한다.
      marker = new naver.maps.Marker({
        position: new naver.maps.LatLng(...coordinates),
        map: map,
        icon: icon,
      });
    }
    // 컴포넌트가 제거될때 실행할 cleanup 함수
    return () => {
      marker?.setMap(null);
    };

    // 지도 객체가 변화가 일어나면 처리하라
    // Dependency Array (의존성배열)
  }, [map]);

  // 네이버 마커 아이콘은 네이버가 랜더링합니다
  return null;
};

export default Marker;
```

- 4. type 추가
     : src/types/map.ts

```ts
import { Coordinates } from './info';

// 네이버 지도 맵에 대한 타입
export type NaverMap = naver.maps.Map;
// 네이버 마커에 이미지 를 데이터 타입
export type ImageIcon = {
  url: string;
  size: naver.maps.Size;
  origin: naver.maps.Point;
  scaledSize: naver.maps.Size;
};

// 네이버 마커를 위한 데이터 타입
export type Marker = {
  map: NaverMap;
  coordinates: Coordinates;
  icon: ImageIcon;
  // 사용작 클릭한 경우 처리
  onClick: () => void;
};
```

- 지도 영역을 클릭하면 아이콘 비활성
- 배포(vercel)

- 검색엔진(네이버)/GA4 등록
- 최적화

- Feedback/About/Intro => TailWind.css
- Feedback(FB) 연동

- 배포(vercel)
